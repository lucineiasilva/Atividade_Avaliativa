
public class Principal {
	public static void main(String[] args) {
		Cliente c1 = new Cliente();
		c1.nome = "Lucineia Pacheco";
		c1.endereco = "Rua 103-20";
		c1.numero = 5012;
		c1.bairro = "BM";
		c1.cidade = "VHA"
		c1,estado = "RO"
		c1.conta = 111111;

		
		
		Cliente c2 = new Cliente();
		c2.nome = "Fabio Luiz";
		c2.endereco = "Rua 103-20";
		c2.numero = 5012;
		c2.bairro = "BM";
		c2.cidade = "VHA"
		c2,estado = "RO"
		c2.conta = 222222;
		
		c1. status();
		c2. status();
	}

}
