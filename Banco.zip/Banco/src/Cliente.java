
public class Cliente {
	public String nome;
	public String endereco;
	public int conta;
	public void status() {
		System.out.println("Novo cliente:" + this.nome);
		System.out.println("Verificando endereço:" + this.endereco);
	}
}