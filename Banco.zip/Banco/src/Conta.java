
public class Conta {
	public int numero;
    private String cliente;
    private float saldo;
    
    public int getNumero() {
        return this.numero;
    }
    public void setNumero(int numero) {
        this.numero = numero;
    }
    public String getCliente() {
        return this.cliente;
    }
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }
    public double getSaldo() {
        return this.saldo;
    }
    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }
    public void sacar() {
    }
    public void depositar() {
    }
    public void Transferir() {
    }

}


