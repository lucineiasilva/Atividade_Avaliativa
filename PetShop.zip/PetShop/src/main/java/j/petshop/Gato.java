package j.petshop;

public class Gato {
 public String nome;
 public String raca;
 public int idade;
 public boolean fivfelv;   
    
}
