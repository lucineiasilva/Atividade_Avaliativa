package j.petshop;

public class Cliente {
  public String nome;
  public  int idade;
  public String endereco;
  public String animal_estimacao;
  public int valor;
  public String descricao;
    
}

