package j.petshop;

public class Endereco {
    public String bairro;
    public String rua;
    public int numero;
    public String cidade;
    public String estado;
    public String cep;
}
