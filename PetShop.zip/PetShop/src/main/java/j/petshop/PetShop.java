package j.petshop;

public class PetShop {

    public static void main(String[] args) {
       Cachorro c1 = new Cachorro();
       c1.servico = "Exame";
       c1.valor = 15.50f;
       c1.cinomose = true;
        
       c1.status();
        
        
       
    }
}
