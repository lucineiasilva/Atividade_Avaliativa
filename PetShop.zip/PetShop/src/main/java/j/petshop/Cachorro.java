package j.petshop;

public class Cachorro {
 public String nome;
 public String raca;
 public int idade;
 public boolean cinomose;
 public String servico;
 public float valor;
 public void status(){
     System.out.println("O serviço realizado foi: " + this.servico);
     System.out.println("O serviço custou: " + this.valor);
 }
 
 
public void setNome(String nome) {
		this.nome = nome;
    }

public float getValor() {
	return valor;
    }
public void setValor(float valor) {
	this.valor = valor;
        
   }
public String getNome() {
	return nome;
    }
public void setRaca(String raca) {
	this.raca = raca;
 
    }
public int getIdade() {
	return idade;
    }
public void setIdade(int idade) {
	this.idade = idade;
    }
public String getServico() {
	return servico;
    }
public void setServico(String servico) {
	this.servico = servico;
    }
public boolean getCinomose() {
	return cinomose;
    }
public void setCinomose(boolean cinomose) {
	this.cinomose = cinomose;
}
        
    }













